---
title: Sample project
description: This is the description of our sample project
date: "2019-05-02T19:47:09+02:00"
jobDate: 2019
work: [design, architecture]
techs: [javascript, D3]
designs: [Photoshop]
thumbnail: sample-project/sample.jpg
projectUrl: https://www.sampleorganization.org
testimonial:
  name: John Doe
  role: CEO @Example
  image: sample-project/john.jpg
  text: Prow scuttle parrel provost Sail ho shrouds spirits boom mizzenmast yardarm. Pinnace holystone mizzenmast quarter crow's nest nipperkin
---

This would be a description of your sample project. You can add any content you'd like.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
proident, sunt in culpa qui officia deserunt mollit anim id est laborum.