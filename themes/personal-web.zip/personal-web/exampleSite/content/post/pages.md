---
title: "Pages"
description: Information on setting up pages
date: 2019-04-20T16:18:12+01:00
publishDate: 2019-04-20T19:12:12+01:00
---

Variables you can use in pages

<!--more-->

The following page variables can be used in default list pages:

* **pagesListSuppressed**
    * false (or missing) - child pages are listed
    * true - child pages are not listed